from typing import List, Dict, Any
from app.repositories.models import Comment
from datetime import datetime

def _comment_to_dict(comment: Comment) -> Dict[str, Any]:
    """ Represent a Comment as a dictionary """
    return {
        "id": comment.id,
        "timestamp": comment.created_at,
        "content": comment.content,
        "author": {
            "id": comment.user.id,
            "name": comment.user.username
        },
        "post": {
            "id": comment.post.id,
            "title": comment.post.title
        },
        "parent": {
            "id": comment.parent_comment.id,
            "author": comment.parent_comment.user.username
        } if comment.parent_comment else None
    }

def build_comment_tree(comments):
    comment_dict = {}
    
    for comment in comments:
        comment_dict[comment.id] = {
            "id": comment.id,
            "timestamp": comment.created_at.strftime('%a, %d %b %Y %H:%M:%S GMT'),
            "author": {
                "id": comment.user.id,
                "username": comment.user.username
            },
            "post": {
                "id": comment.post.id,
                "title": comment.post.title
            },
            "content": comment.content,
            "children": []
        }
    comment_tree = []
    
    for comment in comments:
        if comment.parent_comment is None:
            comment_tree.append(comment_dict[comment.id])
        else:
            parent_comment = comment_dict.get(comment.parent_comment.id)
            if parent_comment:
                parent_comment["children"].append(comment_dict[comment.id])
    
    return comment_tree
    comment_dict = {
        comment.id: {
            "id": comment.id,
            "timestamp": comment.created_at,
            "content": comment.content,
            "author": {
                "id": comment.user.id,
                "name": comment.user.username
            },
            "children": [] 
        }
        for comment in comments
    }

    comment_tree = []

    for comment in comments:
        if comment.parent_comment:
            parent_comment = comment_dict[comment.parent_comment.id]
            parent_comment["children"].append(comment_dict[comment.id])
        else:
            comment_tree.append(comment_dict[comment.id])

    return comment_tree


def build_user_comment_tree(comments: List[Comment], user_id: int) -> List[Dict[str, Any]]:
    """
    Constrói a árvore de comentários para um usuário específico, incluindo a hierarquia de respostas.
    
    Args:
        comments: Lista de comentários do post.
        user_id: ID do usuário alvo.
    
    Returns:
        Lista de dicionários contendo a árvore de comentários com respostas.
    """
    user_comments = [comment for comment in comments if comment.user_id == user_id]
    
    def build_tree_for_comment(comment_id: int) -> Dict[str, Any]:
        comment = next((c for c in comments if c.id == comment_id), None)
        if not comment:
            return None

        children = [
            build_tree_for_comment(child.id)
            for child in comments if child.parent_id == comment_id
        ]
        
        return {
            "id": comment.id,
            "content": comment.content,
            "timestamp": comment.created_at.strftime('%a, %d %b %Y %H:%M:%S GMT'),
            "children": children
        }

    trees = [build_tree_for_comment(comment.id) for comment in user_comments]

    return trees


