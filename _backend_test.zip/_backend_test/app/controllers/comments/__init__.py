from werkzeug.exceptions import NotFound
from flask import Blueprint, jsonify

from app.repositories import comments

from .utils import _comment_to_dict
from .utils import build_comment_tree

BLUEPRINT = Blueprint('comments', __name__)


@BLUEPRINT.route('/comments/<comment_id>')
def get_comment_by_id(comment_id):
    comment = comments.get_comment_by_id(comment_id)

    if comment is None:
        raise NotFound

    return jsonify(_comment_to_dict(comment))

@BLUEPRINT.route('/posts/<post_id>/comments')
def get_comments_from_post(post_id):
    all_comments = comments.get_post_comments(post_id)
    comment_tree = build_comment_tree(all_comments)
    return jsonify(comment_tree)
    # return jsonify([
    #     _comment_to_dict(comment)
    #     for comment in comments.get_post_comments(post_id)
    # ])

@BLUEPRINT.route('/users/<user_id>/comments')
def get_comments_from_user(user_id):
    all_comments = comments.get_user_comments(user_id)

    if not all_comments:
        raise NotFound("Nenhum comentário encontrado para o usuário.")

    posts_comments = {}
    for comment in all_comments:
        if comment.post_id not in posts_comments:
            posts_comments[comment.post_id] = []
        posts_comments[comment.post_id].append(comment)

    comment_tree_response = []
    for post_id, comments_list in posts_comments.items():
        comment_tree = build_comment_tree(comments_list)
        comment_tree_response.append({
            "post_id": post_id,
            "comments": comment_tree,
            
        })

    return jsonify(comment_tree_response)